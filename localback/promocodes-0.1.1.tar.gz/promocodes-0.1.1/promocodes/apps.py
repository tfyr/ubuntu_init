from django.apps import AppConfig


class PromocodesConfig(AppConfig):
    name = 'promocodes'
